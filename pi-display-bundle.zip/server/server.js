const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const PORT = 3000;
const NOTICES_FILE = path.join(__dirname, 'notices.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Ensure uploads directories exist
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
if (!fs.existsSync(path.join(UPLOADS_DIR, 'images'))) fs.mkdirSync(path.join(UPLOADS_DIR, 'images'), { recursive: true });
if (!fs.existsSync(path.join(UPLOADS_DIR, 'videos'))) fs.mkdirSync(path.join(UPLOADS_DIR, 'videos'), { recursive: true });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOADS_DIR));

// Serve React App Build (Static Files)
// This assumes the React app is built into ../build
const BUILD_DIR = path.join(__dirname, '../build');
if (fs.existsSync(BUILD_DIR)) {
    app.use(express.static(BUILD_DIR));
    console.log('Serving React App from ../build');
} else {
    console.warn('React Build directory not found. Run npm run build first.');
}

// Storage Configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, path.join(UPLOADS_DIR, 'images'));
        } else if (file.mimetype.startsWith('video/')) {
            cb(null, path.join(UPLOADS_DIR, 'videos'));
        } else {
            cb(new Error('Invalid file type'), false);
        }
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

// Helper to update notices.json and notify clients
const updateNotice = (type, content) => {
    const noticeData = {
        type,
        content,
        timestamp: new Date().toISOString()
    };

    fs.writeFileSync(NOTICES_FILE, JSON.stringify(noticeData, null, 2));
    io.emit('new_notice', noticeData);
    console.log(`Updated notice: ${type}`);
};

// Initialize notices.json if not exists
if (!fs.existsSync(NOTICES_FILE)) {
    updateNotice('text', 'Waiting for new notice...');
}

// Routes

// Get current notice
app.get('/api/current', (req, res) => {
    if (fs.existsSync(NOTICES_FILE)) {
        const data = fs.readFileSync(NOTICES_FILE);
        res.json(JSON.parse(data));
    } else {
        res.json({ type: 'text', content: 'Welcome' });
    }
});

// Upload Text
app.post('/api/text', (req, res) => {
    const { text } = req.body;
    if (!text) return res.status(400).send('Text is required');

    updateNotice('text', text);
    res.json({ success: true, message: 'Text notice updated' });
});

// Upload Image
app.post('/api/image', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).send('No file uploaded');

    // Construct URL relative to server
    const fileUrl = `/uploads/images/${req.file.filename}`;
    updateNotice('image', fileUrl);
    res.json({ success: true, message: 'Image notice updated', url: fileUrl });
});

// Upload Video
app.post('/api/video', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).send('No file uploaded');

    const fileUrl = `/uploads/videos/${req.file.filename}`;
    updateNotice('video', fileUrl);
    res.json({ success: true, message: 'Video notice updated', url: fileUrl });
});

// Fallback for React Router (Single Page App)
app.get('*', (req, res) => {
    if (fs.existsSync(path.join(BUILD_DIR, 'index.html'))) {
        res.sendFile(path.join(BUILD_DIR, 'index.html'));
    } else {
        res.status(404).send('React App not built or index.html missing.');
    }
});

// WebSocket Connection
io.on('connection', (socket) => {
    console.log('New client connected');

    // Send current notice on connection
    if (fs.existsSync(NOTICES_FILE)) {
        const data = fs.readFileSync(NOTICES_FILE);
        socket.emit('new_notice', JSON.parse(data));
    }

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
});
